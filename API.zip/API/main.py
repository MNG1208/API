from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import threading
from fastapi import WebSocketDisconnect, Request

app = FastAPI()

# Diccionario para almacenar clientes conectados con sus respectivos nombres de usuario
clients = {}

# Objeto para manejar plantillas HTML
templates = Jinja2Templates(directory="templates")


# Ruta principal para cargar la página de chat con solicitud de nombre de usuario
@app.get("/", response_class=HTMLResponse)
async def read_item(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Ruta WebSocket para establecer la conexión WebSocket con el nombre de usuario
@app.websocket("/ws/{username}")
async def websocket_endpoint(websocket: WebSocket, username: str):
    await websocket.accept()

    # Agregar el nuevo cliente al diccionario con su nombre de usuario como clave
    clients[username] = websocket

    try:
        while True:
            data = await websocket.receive_text()
            # Broadcasting del mensaje a todos los clientes conectados
            for client_name, client_ws in clients.items():
                await client_ws.send_text(f"{username}: {data}")
    except WebSocketDisconnect:
        # Remover el cliente cuando se desconecta
        del clients[username]



# Función para iniciar el servidor FastAPI
def start_server():
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)


# Iniciar el servidor en un hilo separado
if __name__ == "__main__":
    server_thread = threading.Thread(target=start_server)
    server_thread.start()
